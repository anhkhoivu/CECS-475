﻿CREATE DATABASE PhoneBook ON (
  NAME='PhoneBook', 
  FILENAME='C:\Users\Anhkhoi\Desktop\phonebook\NewPhoneBook.mdf')
